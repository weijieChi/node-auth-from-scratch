// Reserved for JWT-specific domain errors if needed in the future.

export class JwtError extends Error {}
